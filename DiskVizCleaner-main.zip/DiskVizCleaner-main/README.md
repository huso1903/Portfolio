# DiskVizCleaner

**DiskVizCleaner** est un outil graphique pour analyser l'utilisation de l'espace disque, visualiser les fichiers les plus lourds et générer un script de suppression sécurisé.

## 🚀 Fonctionnalités

- Sélection intuitive du répertoire à analyser (interface graphique)
- Analyse récursive des fichiers avec filtrage par taille
- Visualisation graphique (camembert + légendes)
- Génération d’un script PowerShell pour suppression conditionnelle
- Interface utilisateur ergonomique (PyQt5)

## 📸 Capture d'écran

Voici une visualisation générée par DiskVizCleaner :

![Camembert de fichiers](img/camembert.png)

## 📦 Installation

```bash
git clone https://github.com/cyprienbf/DiskVizCleaner.git
cd DiskVizCleaner
pip install -r requirements.txt
```

## 🧰 Utilisation

```bash
.\main.ps1
```

Cela ouvrira une interface pour :

> 1. Choisir un répertoire
> 2. Analyser les fichiers
> 3. Visualiser les résultats
> 4. Générer un script PowerShell `suppression.ps1` si souhaité

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier [LICENSE](LICENSE) pour plus d'informations.
