import sys, json, random
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QApplication

from lib.Creation_Onglets import Onglets
from lib.Creation_Camembert import Camembert
from lib.Creation_Legendes import Legendes
from lib.Creation_Boutons import Boutons

NB_LEGENDES_PAR_PAGE = 25

def load_json(json_file):
    """Charge les données JSON contenant les fichiers analysés."""
    with open(json_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def generate_colors(n):
    """Génère une liste de couleurs aléatoires pour les fichiers."""
    return [QColor(
        random.randint(0, 255),
        random.randint(0, 255),
        random.randint(0, 255)
    ) for _ in range(n)]

def creation_script_suppression(liste_legende, liste_fichiers):
    """Crée un script PowerShell pour supprimer les fichiers sélectionnés."""
    selected_files = []
    for legende in liste_legende:
        etats = legende.recupere_etats_cases_a_cocher()
        start = legende.num_legende_start
        for i, etat in enumerate(etats):
            if etat and (start + i) < len(liste_fichiers):
                selected_files.append(liste_fichiers[start + i][0])
    
    script = [
        'Write-Output "Script PowerShell pour supprimer des fichiers sans confirmation"',
        'Write-Output "Attention : cette suppression est definitive..."',
        '$reponse = Read-Host "Veuillez confirmer la suppression de tous ces fichiers : (OUI)"',
        'if ($reponse -eq "OUI") {',
        '    $confirmation = Read-Host "Etes-vous bien certain(e) ? (OUI)"',
        '    if ($confirmation -eq "OUI") {'
    ]
    
    for file in selected_files:
        script.append(f'    Remove-Item -Path "{file}" -Force')
    
    script.extend([
        '    } else { Write-Output "Opération annulée..." }',
        '} else { Write-Output "Opération annulée..." }'
    ])
    
    with open('suppression.ps1', 'w', encoding='utf-8') as f:
        f.write('\n'.join(script))

if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Chargement des fichiers analysés
    json_file = 'result.json'
    liste_fichiers = load_json(json_file)
    liste_couleurs = generate_colors(len(liste_fichiers))

    fenetre = Onglets()

    # Ajout du camembert
    camembert = Camembert(liste_fichiers, liste_couleurs)
    fenetre.add_onglet("Camembert", camembert.dessine_camembert())

    # Ajout des légendes (checkbox pour suppression)
    liste_legende = []
    num_pages = (len(liste_fichiers) + NB_LEGENDES_PAR_PAGE - 1) // NB_LEGENDES_PAR_PAGE
    for page in range(num_pages):
        start = page * NB_LEGENDES_PAR_PAGE
        legende = Legendes(liste_fichiers, liste_couleurs, start, NB_LEGENDES_PAR_PAGE)
        layout_legende = legende.dessine_legendes()
        fenetre.add_onglet(f"Légende {page+1}", layout_legende)
        liste_legende.append(legende)

    # Ajout des boutons pour générer le script de suppression
    def callback():
        creation_script_suppression(liste_legende, liste_fichiers)

    boutons = Boutons(sys.argv[1], callback)
    fenetre.add_onglet("IHM", boutons.dessine_boutons())

    fenetre.show()
    sys.exit(app.exec_())
