import argparse, json
from pathlib import Path

def scan_directory(base_dir):
    """Parcourt récursivement un répertoire et collecte les chemins et tailles de fichiers."""
    base_path = Path(base_dir)
    return [
        [str(file.resolve().as_posix()), file.stat().st_size]
        for file in base_path.rglob('*')
        if file.is_file()
    ]

def sort_files(files):
    """Trie les fichiers par taille décroissante."""
    return sorted(files, key=lambda x: x[1], reverse=True)

def filter_files(files, min_size_mb, max_files):
    """Filtre les fichiers par taille minimale et nombre maximal à conserver."""
    min_size = min_size_mb * 1024 * 1024
    filtered = [f for f in files if f[1] >= min_size]
    return filtered[:max_files]

def save_to_json(data, output_file):
    """Sauvegarde les données dans un fichier JSON."""
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyse et filtre les fichiers d'un répertoire.")
    parser.add_argument('directory', help="Répertoire à analyser")
    parser.add_argument('--min-size', type=int, default=10, help="Taille minimale (en Mo)")
    parser.add_argument('--max-files', type=int, default=100, help="Nombre maximal de fichiers à conserver")
    parser.add_argument('--output', default='result.json', help="Fichier de sortie JSON")
    args = parser.parse_args()

    files = scan_directory(args.directory)
    sorted_files = sort_files(files)
    filtered_files = filter_files(sorted_files, args.min_size, args.max_files)
    save_to_json(filtered_files, args.output)
