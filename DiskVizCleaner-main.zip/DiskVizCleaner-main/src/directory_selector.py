import sys
from pathlib import Path
from PyQt5.QtWidgets import QApplication, QFileDialog

def select_directory():
    # Initialise l'application Qt
    app = QApplication(sys.argv)
    app.setApplicationName("Sélection du répertoire de base")

    # Ouvre une boîte de dialogue pour sélectionner un répertoire
    directory = QFileDialog.getExistingDirectory(
        None,
        "Sélectionner un répertoire à analyser",
        str(Path.home()),  # répertoire de départ
        QFileDialog.ShowDirsOnly
    )

    if directory:
        # Affiche le chemin absolu du répertoire (format Unix)
        print(Path(directory).resolve().as_posix())
    else:
        print("Aucun répertoire sélectionné")
    
    return directory

if __name__ == "__main__":
    select_directory()
    sys.exit(0)
