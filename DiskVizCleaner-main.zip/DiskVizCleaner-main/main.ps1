# Stoppe le script en cas d'erreur
$ErrorActionPreference = "Stop"

# Positionne le répertoire courant sur celui du script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $scriptDir

# Étape 1 : Sélection du répertoire via interface graphique
$rep_base = python -u .\src\directory_selector.py
if (-not $rep_base) {   
    Write-Output "Aucun répertoire sélectionné"
    exit
}

# Étape 2 : Analyse du disque (taille min 10 Mo, max 100 fichiers)
python -u ".\src\disk_analyzer.py" "$rep_base" --min-size 10 --max-files 100 --output ".\result.json"

# Étape 3 : Lancement de l'interface visuelle si JSON généré
if (Test-Path ".\result.json") {
    python -u ".\src\visual_report.py" "$rep_base"
} else {
    Write-Output "Erreur lors de la génération du JSON"
}
